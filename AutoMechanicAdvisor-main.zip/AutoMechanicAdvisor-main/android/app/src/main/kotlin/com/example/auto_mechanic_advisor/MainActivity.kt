package com.example.auto_mechanic_advisor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
