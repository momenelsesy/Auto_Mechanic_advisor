const baseUrl = 'https://2dc8-156-203-232-36.ngrok-free.app';

const loginendpoint = '/login';

const registerendPoint = '/register';

const userendpoint = '/user-details';

const mechanicendpoint = '/get-mechanics';

const exploreendpoint = '/explore';

const chatendpoint = '/chat';
