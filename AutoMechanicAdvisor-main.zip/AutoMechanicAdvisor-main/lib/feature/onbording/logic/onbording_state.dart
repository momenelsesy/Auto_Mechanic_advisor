part of 'onbording_cubit.dart';

// Define a sealed class for OnboardingState
@immutable
sealed class OnboardingState {}

final class OnboardingInitial extends OnboardingState {}
